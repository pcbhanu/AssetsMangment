﻿using System;
using System.ComponentModel.DataAnnotations;

namespace StockAudit.Models
{
    public class StockAuditViewModel
    {
        [Key]
        public int Id { get; set; } = 0;
        public string JobNumber { get; set; } = "";
        public string COL1 { get; set; } = "";
        public int COL2 { get; set; } = 0;
        public string COL3 { get; set; } = "";
        public string COL4 { get; set; } = "";
        public string COL5 { get; set; } = "";
        public string COL6 { get; set; } = "";
        public string COL7 { get; set; } = "";
        public string COL8 { get; set; } = "";
        public string COL9 { get; set; } = "";
        public DateTime CreatedOn { get; set; }
    }
}
