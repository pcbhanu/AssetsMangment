﻿using System;
using System.ComponentModel.DataAnnotations;

namespace StockAudit.Models
{
    public class JobCreationViewModel
    {
        public int Id { get; set; } = 0;
        [Required(ErrorMessage = "JobNumber is required.")]
        public string JobNumber { get; set; } = "";
        public DateTime CreatedOn { get; set; }
    }
}
