﻿using Microsoft.AspNetCore.Mvc;
using StockAudit.Models;
using StockAudit.Service;
using System.Collections.Generic;

namespace StockAudit.Controllers
{
    public class JobCreationController : Controller
    {
        IJobCreationService _jobCreationService = null;
        List<JobCreationViewModel> _stockAudits = new List<JobCreationViewModel>();
        public JobCreationController(IJobCreationService jobCreationService)
        {
            _jobCreationService = jobCreationService;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult GetJobNumber()
        {
            List<JobCreationViewModel> lst = _jobCreationService.GetJobCreationList();           
            return Json(lst);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(JobCreationViewModel jobCreationViewModel)
        {
            if (!ModelState.IsValid)
            {
                return View(jobCreationViewModel);
            }
            var JobNumber = jobCreationViewModel.JobNumber;
            var CreatedOn = jobCreationViewModel.CreatedOn;
            _jobCreationService.SaveJobNumber(JobNumber, CreatedOn);
            return RedirectToAction(nameof(Create));
        }
    }
}
