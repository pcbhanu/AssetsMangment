﻿using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using StockAudit.Models;
using StockAudit.Service;
using System;
using System.Collections.Generic;
using System.Linq;

namespace StockAudit.Controllers
{
    public class StockAuditController : Controller
    {
        IStockAuditService _stockAuditService = null;
        IJobCreationService _jobCreationService = null;
        List<StockAuditViewModel> _stockAudits = new List<StockAuditViewModel>();

        public StockAuditController(IStockAuditService stockAuditService, IJobCreationService jobCreationService)
        {
            _stockAuditService = stockAuditService;
            _jobCreationService = jobCreationService;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult GetJobNumber()
        {
            List<JobCreationViewModel> lst = _jobCreationService.GetJobCreationList();
            return Json(lst);
        }
        public JsonResult SaveStockAudit(List<StockAuditViewModel> stockAudits)
        {
            stockAudits.ToList().ForEach(c => c.CreatedOn = DateTime.Now);
            foreach (var stockadt in stockAudits)
            {
                if (stockadt.JobNumber == "Please select Job Number")
                {
                    List<StockAuditViewModel> jobnumberlist = _stockAuditService.GetJobNumber();
                    stockadt.JobNumber = jobnumberlist[0].JobNumber;
                    stockadt.CreatedOn = DateTime.Now;
                }
            }
            _stockAudits = _stockAuditService.SaveStockAudit(stockAudits);
            var JobNumber = stockAudits.ToList().Select(x => x.JobNumber).FirstOrDefault();
            var CreatedOn = stockAudits.ToList().Select(x => x.CreatedOn).FirstOrDefault();
            var lst = _jobCreationService.GetJobCreationList().ToArray();
            if (lst.Length > 0)
            {
                var jobnum = lst.Where(x => x.JobNumber == JobNumber).Any();
                if (jobnum == false)
                {
                    var savejobnumber = _stockAuditService.SaveJobNumber(JobNumber, CreatedOn);
                }
            }
            else
            {
                var savejobnumber = _stockAuditService.SaveJobNumber(JobNumber, CreatedOn);
            }
            return Json(_stockAudits);
        }
        public string GenerateAndDownloadExcel(int Id, string name)
        {

            List<StockAuditViewModel> stockAudits = _stockAuditService.GetStockAudit();
            var datatable = CommonMethods.ConvertListToDataTable(stockAudits);
            datatable.Columns.Remove("Id");
            datatable.Columns.Remove("JobNumber");
            datatable.Columns.Remove("CreatedOn");

            byte[] filecontents = null;

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            using (ExcelPackage pck = new ExcelPackage())
            {
                ExcelWorksheet ws = pck.Workbook.Worksheets.Add("StockAudits");
                ws.Cells["A1"].Value = "Stock Audits";
                ws.Cells["A1"].Style.Font.Bold = true;
                ws.Cells["A1"].Style.Font.Size = 16;
                ws.Cells["A1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                ws.Cells["A1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

                ws.Cells["A2"].Value = "Stock List";
                ws.Cells["A2"].Style.Font.Bold = true;
                ws.Cells["A2"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                ws.Cells["A2"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

                ws.Cells["A3"].LoadFromDataTable(datatable, true);
                ws.Cells["A3:I3"].Style.Font.Bold = true;
                ws.Cells["A3:I3"].Style.Font.Size = 12;
                ws.Cells["A3:I3"].Style.Fill.PatternType = ExcelFillStyle.Solid;
                ws.Cells["A3:I3"].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.SkyBlue);
                ws.Cells["A3:I3"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                ws.Cells["A3:I3"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

                pck.Save();
                filecontents = pck.GetAsByteArray();
            }
            return Convert.ToBase64String(filecontents);
        }
    }
}
