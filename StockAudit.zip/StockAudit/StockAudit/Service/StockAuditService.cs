﻿using EFCore.BulkExtensions;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using StockAudit.Context;
using StockAudit.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace StockAudit.Service
{
    public class StockAuditService : IStockAuditService
    {
        DatabaseContext _dbcontext = null;
        public StockAuditService(DatabaseContext dbcontext)
        {
            _dbcontext = dbcontext;
        }

        public List<StockAuditViewModel> GetJobNumber()
        {
            DataSet ds = new DataSet();
            List<StockAuditViewModel> jobnumberdata = new List<StockAuditViewModel>();
            using (var connection = new SqlConnection(_dbcontext.Database.GetDbConnection().ConnectionString))
            {
                connection.Open();
                string strSQL = "Get_JobNumber_Serial";
                SqlDataAdapter dt = new SqlDataAdapter(strSQL, connection);
                dt.SelectCommand.CommandType = CommandType.StoredProcedure;
                dt.Fill(ds, "Get_JobNumber_Serial");
                connection.Close();
                DataTable firstTable = ds.Tables[0];
                jobnumberdata = (from DataRow dr in firstTable.Rows
                                 select new StockAuditViewModel()
                                 {
                                     JobNumber = dr["JobNumber"] == DBNull.Value ? "" : (string)dr["JobNumber"],
                                 }).ToList();
            }
            return jobnumberdata;
        }

        public List<StockAuditViewModel> GetStockAudit()
        {
            return _dbcontext.StockAudit.ToList();
        }

        public Task<bool> SaveJobNumber(string jobNumber, DateTime CreatedOn)
        {
            try
            {
                using (var connection = new SqlConnection(_dbcontext.Database.GetDbConnection().ConnectionString))
                {
                    SqlCommand command = new SqlCommand("InsertJobNumber", connection);
                    command.Connection = connection;
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@jobNumber", jobNumber);
                    command.Parameters.AddWithValue("@createdOn", CreatedOn);
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return Task.FromResult(true);
        }

        public List<StockAuditViewModel> SaveStockAudit(List<StockAuditViewModel> stockAudits)
        {
            _dbcontext.BulkInsert(stockAudits);
            return stockAudits;
        }
    }
}
