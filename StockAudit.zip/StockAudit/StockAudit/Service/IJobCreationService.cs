﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using StockAudit.Models;

namespace StockAudit.Service
{
    public interface IJobCreationService
    {
        List<JobCreationViewModel> GetJobCreationList();
        Task<bool> SaveJobNumber(string jobNumber, DateTime CreatedOn);
    }
}
