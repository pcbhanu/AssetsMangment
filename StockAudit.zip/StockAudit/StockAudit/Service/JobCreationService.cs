﻿using EFCore.BulkExtensions;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using StockAudit.Context;
using StockAudit.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace StockAudit.Service
{
    public class JobCreationService : IJobCreationService
    {
        DatabaseContext _dbcontext = null;
        public JobCreationService(DatabaseContext dbcontext)
        {
            _dbcontext = dbcontext;
        }
        public List<JobCreationViewModel> GetJobCreationList()
        {
            DataSet ds = new DataSet();
            List<JobCreationViewModel> jobnumberlist = new List<JobCreationViewModel>();
            using (var connection = new SqlConnection(_dbcontext.Database.GetDbConnection().ConnectionString))
            {
                connection.Open();
                string strSQL = "Get_JobNumber";
                SqlDataAdapter dt = new SqlDataAdapter(strSQL, connection);
                dt.SelectCommand.CommandType = CommandType.StoredProcedure;
                dt.Fill(ds, "Get_JobNumber");
                connection.Close();
                DataTable firstTable = ds.Tables[0];
                jobnumberlist = (from DataRow dr in firstTable.Rows
                                 select new JobCreationViewModel()
                                 {
                                     Id = dr["Id"] == DBNull.Value ? 0 : (int)dr["Id"],
                                     JobNumber = dr["JobNumber"] == DBNull.Value ? "" : (string)dr["JobNumber"],
                                 }).ToList();
            }
            return jobnumberlist;
        }

        public Task<bool> SaveJobNumber(string jobNumber, DateTime CreatedOn)
        {
            try
            {
                using (var connection = new SqlConnection(_dbcontext.Database.GetDbConnection().ConnectionString))
                {
                    SqlCommand command = new SqlCommand("InsertJobNumber", connection);
                    command.Connection = connection;
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@jobNumber", jobNumber);
                    command.Parameters.AddWithValue("@createdOn", CreatedOn);
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return Task.FromResult(true);
        }
    }
}
