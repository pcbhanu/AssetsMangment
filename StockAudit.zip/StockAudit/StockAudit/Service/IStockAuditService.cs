﻿using StockAudit.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace StockAudit.Service
{
    public interface IStockAuditService
    {
        List<StockAuditViewModel> GetStockAudit();
        List<StockAuditViewModel> SaveStockAudit(List<StockAuditViewModel> stockAudits);
        List<StockAuditViewModel> GetJobNumber();
        Task<bool> SaveJobNumber(string jobNumber, DateTime CreatedOn);
    }
}
