﻿using Microsoft.EntityFrameworkCore;
using StockAudit.Models;

namespace StockAudit.Context
{
    public class DatabaseContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            var connectionstring = string.Format(@"Data Source=43.230.201.20,1232;Initial Catalog=StockAudit;Persist Security Info=True;User ID=sa;Password=Yu6SBA5s4u#zcT6%e");
            options.UseSqlServer(connectionstring);
        }

        public DbSet<StockAuditViewModel> StockAudit { get; set; }
    }
}
